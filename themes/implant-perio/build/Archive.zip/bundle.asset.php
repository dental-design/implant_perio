<?php return array('dependencies' => array('jquery'), 'version' => 'a6a3076be62b776fe8be');
